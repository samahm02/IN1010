public class Koe<T> extends Lenkeliste<T> {
    /*public class Koe<T> extends Lenkeliste<T> {
    }
    */

}
