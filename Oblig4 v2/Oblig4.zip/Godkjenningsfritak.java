public interface Godkjenningsfritak {
    public String hentKontrollID();
}