public class Slangespillet {
    public static void main(String[] args) throws InterruptedException {
        Kontroll kontroller = new Kontroll();
        kontroller.spill();
    }
}